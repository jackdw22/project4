//
// Created by james on 10/26/2021.
//

#ifndef HEADER_H
#define HEADER_H
#include <vector>
#include <string>


class Header {
public:
    std::vector<std::string> values;

};


#endif //PROJECT1_HEADER_H
